package com.example.mhp3launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_SETUP = "com.example.mhp3launcher.SETUP"
        const val PPSSPP_ACTIVITY = "org.ppsspp.ppsspp.PpssppActivity"
        const val PKG_FREE = "org.ppsspp.ppsspp"
        const val PKG_GOLD = "org.ppsspp.ppssppgold"
        const val DEFAULT_GAME = "/storage/emulated/0/MHP3RD/mhp3rd.iso"
    }

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private var pickedUri: String? = null
    private lateinit var info: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            pickedUri = uri.toString()
            info.text = "Dipilih:\n$pickedUri"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val setupMode = intent?.action == ACTION_SETUP
        val saved = prefs.getString("game", DEFAULT_GAME)

        if (!setupMode && saved != null) {
            if (launchGame()) { finish(); return }
        }
        showSetup()
    }

    private fun launchGame(): Boolean {
        val game = prefs.getString("game", DEFAULT_GAME) ?: return false
        val pkg = prefs.getString("pkg", PKG_FREE) ?: PKG_FREE

        // Izinkan file:// URI dikirim ke PPSSPP (dibutuhkan untuk path manual)
        try {
            android.os.StrictMode.setVmPolicy(android.os.StrictMode.VmPolicy.Builder().build())
        } catch (_: Exception) { }

        val uri = if (game.startsWith("/")) Uri.parse("file://$game") else Uri.parse(game)

        val i = Intent(Intent.ACTION_VIEW).apply {
            setClassName(pkg, PPSSPP_ACTIVITY)
            setDataAndType(uri, "*/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            startActivity(i)
            true
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "PPSSPP tidak ditemukan. Cek versi (Free/Gold).", Toast.LENGTH_LONG).show()
            false
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka game: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun showSetup() {
        window.setBackgroundDrawableResource(android.R.color.white)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Pengaturan MHP3rd HD Launcher"
            textSize = 20f
            gravity = Gravity.START
        })

        root.addView(TextView(this).apply { text = "\n1. Pilih versi PPSSPP yang terinstall:" })
        val group = RadioGroup(this)
        val rFree = RadioButton(this).apply { text = "PPSSPP (gratis)"; id = 1 }
        val rGold = RadioButton(this).apply { text = "PPSSPP Gold"; id = 2 }
        group.addView(rFree); group.addView(rGold)
        if (prefs.getString("pkg", PKG_FREE) == PKG_GOLD) rGold.isChecked = true else rFree.isChecked = true
        root.addView(group)

        root.addView(TextView(this).apply { text = "\n2. Pilih file ISO/CSO game:" })
        info = TextView(this).apply {
            text = prefs.getString("game", DEFAULT_GAME) ?: DEFAULT_GAME
        }
        root.addView(Button(this).apply {
            text = "Pilih file game"
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        })
        root.addView(info)

        root.addView(TextView(this).apply {
            text = "\nAtau ketik path manual (opsional, kalau pemilih file gagal):"
        })
        val pathInput = EditText(this).apply {
            hint = DEFAULT_GAME
            setSingleLine(true)
        }
        root.addView(pathInput)

        root.addView(Button(this).apply {
            text = "Simpan & Main"
            setOnClickListener {
                val manual = pathInput.text.toString().trim()
                val game = when {
                    manual.isNotEmpty() -> manual
                    pickedUri != null -> pickedUri
                    else -> prefs.getString("game", null)
                }
                if (game == null) {
                    Toast.makeText(this@MainActivity, "Pilih file game dulu", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit()
                    .putString("game", game)
                    .putString("pkg", if (group.checkedRadioButtonId == 2) PKG_GOLD else PKG_FREE)
                    .apply()
                if (launchGame()) finish()
            }
        })

        root.addView(TextView(this).apply {
            text = "\nTips: tahan lama ikon app ini lalu pilih \"Pengaturan\" untuk membuka layar ini lagi."
            textSize = 12f
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
