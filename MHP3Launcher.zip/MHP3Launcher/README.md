# MHP3rd HD Launcher

App kecil: sekali tap -> langsung buka PPSSPP dengan game MHP3rd HD.

## Cara build
1. Install Android Studio (versi terbaru).
2. File > Open > pilih folder MHP3Launcher ini. Tunggu Gradle sync (butuh internet).
3. Colok HP (USB debugging aktif) lalu klik Run, atau Build > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/

## Cara pakai
- Buka app pertama kali -> pilih versi PPSSPP + file ISO -> Simpan & Main.
- Selanjutnya sekali tap langsung masuk game.
- Ubah pengaturan: tahan ikon app -> "Pengaturan".

## Ganti nama/ikon
- Nama: app/src/main/res/values/strings.xml (app_name)
- Ikon: ganti app/src/main/res/drawable/ic_launcher.xml
